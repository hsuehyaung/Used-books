<template>
  <div>
    <!-- 轮播图区域 -->
    <div class="book-carousel">
      <img src="../assets/image/gs1.jpg" alt="图书轮播图1">
      <img src="图书轮播图2.jpg" alt="图书轮播图2">
      <!-- 可以添加更多的轮播图 -->
    </div>

    <!-- 图书信息区域 -->
    <div class="book-info">
      <h1>{{ bookName }}</h1>
      <p>ISBN: {{ isbn }}</p>
      <p>价格: {{ price }}</p>
      <p>库存: {{ stock }}</p>
      <!-- 可以添加更多的图书信息 -->
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      bookName: '图书名称',
      isbn: 'ISBN 编号',
      price: '价格',
      stock: '库存数量'
      // 可以在这里初始化更多的图书信息
    }
  }
}
</script>

<style scoped>
.book-carousel {
  width: 100%;
  height: 400px;
  overflow: hidden;
}

.book-carousel img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.book-info {
  margin-top: 20px;
  text-align: center;
}

.book-info h1 {
  font-size: 24px;
  margin-bottom: 10px;
}

.book-info p {
  font-size: 16px;
  margin-bottom: 5px;
}
</style>